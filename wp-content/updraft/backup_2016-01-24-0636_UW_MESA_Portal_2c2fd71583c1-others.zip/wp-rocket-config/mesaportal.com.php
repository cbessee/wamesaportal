<?php
defined( 'ABSPATH' ) or die( 'Cheatin\' uh?' );

$rocket_cookie_hash = '17f9f5096cd1ba20f283211aec5c0899';
$rocket_secret_cache_key = '566933e067421795641118';
$rocket_cache_reject_uri = '.*/feed/?';
$rocket_cache_reject_cookies = 'wordpress_logged_in_|wp-postpass_|wptouch_switch_toggle|comment_author_|comment_author_email_';
$rocket_cache_query_strings = array (
);
$rocket_cache_reject_ua = 'facebookexternalhit';
