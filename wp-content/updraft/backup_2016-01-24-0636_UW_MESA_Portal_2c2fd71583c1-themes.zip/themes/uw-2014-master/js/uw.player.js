// ### UW HTML5 Player

// This function creates a UW HTML5 player
// For usage please refer to the [UW Web Components Player](http://uw.edu/brand/web/#player)

UW.Player = Backbone.View.extend({

  defaults : {

  },

  initialize: function( options )
  {

    // _.bindAll( this )

    // this.settings = _.extend( {}, this.defaults , this.$el.data() , options )

    // console.log(videojs);


  }


})
