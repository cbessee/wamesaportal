<?php
if (( is_search() || is_archive() || is_front_page() )){
  uw_mobile_front_page_menu();
} else {
  uw_mobile_menu();
}
?>
