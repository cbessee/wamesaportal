=== WP Idle Logout ===
Contributors: cdukes
Tags: idle, logout, inactive, autologout, auto-logout, security
Requires at least: 3.5
Tested up to: 3.5
Stable tag: 1.0.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Automatically logs out inactive users.

== Description ==

Automatically logs out inactive users.

[Check it out on GitHub.](http://github.com/cdukes/wp-idle-logout)

== Installation ==

1. Upload the `wp-idle-logout` folder to the `/wp-content/plugins/` directory
1. Activate the WP Idle Logout plugin through the 'Plugins' menu in WordPress
1. Configure the plugin by going to the Settings > Idle Logout menu in your admin menu

== Changelog ==

= 1.0.1 =
* Fixes incorrectly private clear_activity_meta function

= 1.0.0 =
* Initial version.