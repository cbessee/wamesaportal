== Note to Translators ==

Note: This folder contains the MO files and the POT file. If you would like the PO files (for example if you want to improve an existing translation), you can download them here:

http://plugins.svn.wordpress.org/wp-spamshield/branches/languages/

If you would like to be a translator for WP-SpamShield or have created a translation that you'd like to contribute, please email it to me at: <wpspamshield@redsandmarketing.com> and I'll include it in the next release.

Thank you!

- Scott Allen