
<div class="uw-hero-image" <?php if ( get_header_image() !== '' )  { ?> style="background-image:url('<?php echo set_url_scheme( get_header_image() ); ?>');"<?php } ?> ></div>
